import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
import os

input_file = r'D:\data\Tsin\New Microsoft Excel Worksheet.csv'
output_file = r'D:\data\Tsin\sinusoidal_temperature_output.xlsx'
df = pd.read_csv(input_file)
temp_data = df['Temperature'].values
months = np.arange(len(temp_data))

def sinusoidal(x, amplitude, frequency, phase, offset):
    return amplitude * np.sin(frequency * x + phase) + offset

initial_guess = [
    (max(temp_data) - min(temp_data)) / 2,  
    2 * np.pi / 12,                         
    0,                                      
    np.mean(temp_data)                     
]

params, covariance = curve_fit(
    sinusoidal,
    months,
    temp_data,
    p0=initial_guess
)

amplitude, frequency, phase, offset = params

sin_wave = sinusoidal(
    months,
    amplitude,
    frequency,
    phase,
    offset
)

df['Sinusoidal_Temperature'] = sin_wave

ss_res = np.sum((temp_data - sin_wave) ** 2)
ss_tot = np.sum((temp_data - np.mean(temp_data)) ** 2)
r2 = 1 - (ss_res / ss_tot)

df.to_excel(output_file, index=False)

print("\nfitting was successful")
print(f"Amplitude = {amplitude:.4f}")
print(f"Frequency = {frequency:.4f}")
print(f"Phase = {phase:.4f}")
print(f"Offset = {offset:.4f}")
print(f"R² = {r2:.4f}")
print(output_file)